﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Shopping_Tutorial.Models;
using Shopping_Tutorial.Repository;

namespace Shopping_Tutorial.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Route("Admin/Brand")]
    [Authorize(Roles = "Admin")]
    public class BrandController : Controller
    {
        private readonly DataContext _dataContext;

        public BrandController(DataContext context)
        {
            _dataContext = context;
        }

        [HttpGet]
        [Route("Index")]
        public async Task<IActionResult> Index(string searchTerm, int? page, int? pageSize)
        {
            // Lưu từ khóa tìm kiếm vào ViewData
            ViewData["CurrentFilter"] = searchTerm;

            // Truy vấn dữ liệu từ bảng Brands
            var brands = _dataContext.Brands.AsQueryable();

            // Áp dụng tìm kiếm nếu có từ khóa
            if (!string.IsNullOrEmpty(searchTerm))
            {
                brands = brands.Where(b => b.Name.Contains(searchTerm) ||
                                            b.Description.Contains(searchTerm) ||
                                            b.Slug.Contains(searchTerm));
            }

            // Kiểm tra và gán giá trị mặc định cho trang và số lượng trang
            if (page == null)
            {
                page = 1;
            }
            if (pageSize == null)
            {
                pageSize = 5;
            }

            // Tính toán tổng số mục
            var totalItems = await brands.CountAsync();

            // Tính tổng số trang
            var pageCount = (int)Math.Ceiling(totalItems / (double)pageSize);

            // Lưu vào ViewData để sử dụng trong View
            ViewData["PageCount"] = pageCount;
            ViewData["CurrentPage"] = page;

            // Áp dụng phân trang
            var pagedBrands = brands.OrderByDescending(b => b.Id)
                                    .Skip((page.Value - 1) * pageSize.Value) // Bỏ qua các mục ở các trang trước
                                    .Take(pageSize.Value); // Lấy các mục cho trang hiện tại

            // Chuyển kết quả sang danh sách
            var brandList = await pagedBrands.ToListAsync();

            // Trả về View với danh sách thương hiệu đã phân trang
            return View(brandList);
        }

        [HttpGet]
        [Route("Create")]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [Route("Create")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(BrandModel brand)
        {
            if (ModelState.IsValid)
            {
                // Thêm data
                brand.Slug = brand.Name.Replace(" ", "-");

                // Kiểm tra slug đã tồn tại
                var slug = await _dataContext.Brands.FirstOrDefaultAsync(p => p.Slug == brand.Slug);
                if (slug != null)
                {
                    ModelState.AddModelError("", "Slug đã tồn tại.");
                    return View(brand);
                }

                _dataContext.Add(brand);
                await _dataContext.SaveChangesAsync();
                TempData["success"] = "Thêm thương hiệu thành công";
                return RedirectToAction("Index");
            }
            else
            {
                TempData["error"] = "Model bị lỗi";
                List<string> errors = new List<string>();
                foreach (var value in ModelState.Values)
                {
                    foreach (var error in value.Errors)
                    {
                        errors.Add(error.ErrorMessage);
                    }
                }
                string errorMessage = string.Join("\n", errors);
                return BadRequest(errorMessage);
            }
        }

        [HttpGet]
        [Route("Edit/{Id}")]
        public async Task<IActionResult> Edit(int Id)
        {
            // Lấy thương hiệu theo Id
            var brand = await _dataContext.Brands.FindAsync(Id);

            if (brand == null)
            {
                TempData["error"] = "Không tìm thấy thương hiệu.";
                return RedirectToAction("Index");
            }

            return View(brand);
        }

        [HttpPost]
        [Route("Edit/{Id}")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int Id, BrandModel brand)
        {
            if (Id != brand.Id)
            {
                TempData["error"] = "ID không hợp lệ.";
                return RedirectToAction("Index");
            }

            if (ModelState.IsValid)
            {
                // Cập nhật slug khi thay đổi tên thương hiệu
                brand.Slug = brand.Name.Replace(" ", "-");

                // Kiểm tra slug đã tồn tại trong cơ sở dữ liệu chưa
                var existingBrand = await _dataContext.Brands
                    .FirstOrDefaultAsync(p => p.Slug == brand.Slug && p.Id != brand.Id);

                if (existingBrand != null)
                {
                    ModelState.AddModelError("", "Slug này đã tồn tại.");
                    return View(brand);
                }

                // Cập nhật thông tin thương hiệu
                _dataContext.Update(brand);
                await _dataContext.SaveChangesAsync();
                TempData["success"] = "Cập nhật thương hiệu thành công.";
                return RedirectToAction("Index");
            }

            // Nếu có lỗi, hiển thị lại form với thông báo lỗi
            TempData["error"] = "Cập nhật không thành công.";
            return View(brand);
        }

		[HttpGet]
		[Route("Delete")]
		public async Task<IActionResult> Delete(int Id)
		{
			try
			{
				// Tìm thương hiệu theo Id
				var brand = await _dataContext.Brands.FindAsync(Id);

				if (brand == null)
				{
					TempData["error"] = "Không tìm thấy thương hiệu.";
					return RedirectToAction("Index");
				}

				// Kiểm tra xem có sản phẩm nào thuộc thương hiệu này không
				var products = await _dataContext.Products
												 .Where(p => p.BrandId == Id)
												 .ToListAsync();

				if (products.Any())
				{
					TempData["error"] = "Không thể xóa thương hiệu vì có sản phẩm thuộc thương hiệu này.";
					return RedirectToAction("Index");
				}

				// Nếu không có sản phẩm nào, tiến hành xóa thương hiệu
				_dataContext.Brands.Remove(brand);
				await _dataContext.SaveChangesAsync();

				TempData["success"] = "Thương hiệu đã xóa thành công.";
				return RedirectToAction("Index");
			}
			catch (DbUpdateException ex)
			{
				// Nếu có lỗi khi cập nhật cơ sở dữ liệu (ví dụ: có liên kết khóa ngoại)
				TempData["error"] = $"Lỗi khi xóa thương hiệu: {ex.Message}";
				return RedirectToAction("Index");
			}
			catch (Exception ex)
			{
				// Xử lý các lỗi khác
				TempData["error"] = $"Đã xảy ra lỗi: {ex.Message}";
				return RedirectToAction("Index");
			}
		}


		[HttpGet]
        [Route("Details/{id}")]
        public async Task<IActionResult> Details(int id)
        {
            var brand = await _dataContext.Brands.FirstOrDefaultAsync(b => b.Id == id);


            if (brand == null)
            {
                return NotFound(); // Nếu không tìm thấy thương hiệu
            }

            return View(brand); // Trả về view chi tiết thương hiệu
        }
    }
}
