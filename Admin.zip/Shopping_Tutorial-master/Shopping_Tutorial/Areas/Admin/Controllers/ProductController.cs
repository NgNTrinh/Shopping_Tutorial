﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Shopping_Tutorial.Models;
using Shopping_Tutorial.Repository;
using PagedList;

namespace Shopping_Tutorial.Areas.Admin.Controllers
{
	[Area("Admin")]
    [Route("Admin/Product")]
  	[Authorize(Roles = "Admin")]
    public class ProductController : Controller
	{
		private readonly DataContext _dataContext;
		private readonly IWebHostEnvironment _webHostEnvironment;//Để load file
		public ProductController(DataContext context, IWebHostEnvironment webHostEnvironment)
		{
			_dataContext = context;
			_webHostEnvironment = webHostEnvironment;
		}
        [HttpGet]
        [Route("Index")]

        public async Task<IActionResult> Index(string searchQuery, int? page, int? pageSize)
        {
            // Tạo truy vấn cơ sở để lọc theo tên sản phẩm, danh mục và thương hiệu
            var productsQuery = _dataContext.Products
                .OrderByDescending(p => p.Id)
                .Include(p => p.Category)
                .Include(p => p.Brand)
                .AsQueryable();

            // Nếu có từ khóa tìm kiếm, lọc theo tên sản phẩm, danh mục hoặc thương hiệu
            if (!string.IsNullOrEmpty(searchQuery))
            {
                productsQuery = productsQuery.Where(p => p.Name.Contains(searchQuery) ||
                                                         p.Category.Name.Contains(searchQuery) ||
                                                         p.Brand.Name.Contains(searchQuery));
            }

            // Kiểm tra và gán giá trị mặc định cho trang và số lượng trang
            int currentPage = page ?? 1;  // Mặc định trang đầu tiên là 1
            int currentPageSize = pageSize ?? 5;  // Mặc định mỗi trang có 5 sản phẩm

            // Tính toán tổng số mục
            var totalItems = await productsQuery.CountAsync();

            // Tính tổng số trang
            var pageCount = (int)Math.Ceiling(totalItems / (double)currentPageSize);

            // Lưu vào ViewData để sử dụng trong View
            ViewData["PageCount"] = pageCount;
            ViewData["CurrentPage"] = currentPage;

            // Áp dụng phân trang
            var products = await productsQuery
                .Skip((currentPage - 1) * currentPageSize)  // Bỏ qua các phần tử của các trang trước
                .Take(currentPageSize)  // Lấy số lượng phần tử theo pageSize
                .ToListAsync();

            // Trả lại view với danh sách sản phẩm và từ khóa tìm kiếm
            ViewData["searchQuery"] = searchQuery;
            ViewData["currentPage"] = currentPage;
            ViewData["pageSize"] = currentPageSize;

            return View(products);
        }



        [HttpGet]
        [Route("Create")]
        public IActionResult Create()
        {
            // Lọc các danh mục và thương hiệu có trạng thái "Hiển thị"
            ViewBag.Categories = new SelectList(_dataContext.Categories.Where(c => c.Status == 1), "Id", "Name");
            ViewBag.Brands = new SelectList(_dataContext.Brands.Where(b => b.Status == 1), "Id", "Name");
            return View();
        }

        [HttpPost]
        [Route("Create")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(ProductModel product)
        {
            ViewBag.Categories = new SelectList(_dataContext.Categories.Where(c => c.Status == 1), "Id", "Name");
            ViewBag.Brands = new SelectList(_dataContext.Brands.Where(b => b.Status == 1), "Id", "Name");

            // Kiểm tra model state, bao gồm ảnh
            if (ModelState.IsValid)
            {
                product.Slug = product.Name.Replace(" ", "-");

                // Kiểm tra sản phẩm đã tồn tại hay chưa
                if (await _dataContext.Products.AnyAsync(p => p.Slug == product.Slug))
                {
                    ModelState.AddModelError("", "Sản phẩm đã tồn tại với tên này. Vui lòng chọn tên khác.");
                    return View(product);
                }

                // Kiểm tra nếu ảnh tải lên là null hoặc không có
                if (product.ImageUpload == null || product.ImageUpload.Length == 0)
                {
                    ModelState.AddModelError("ImageUpload", "Ảnh sản phẩm là bắt buộc.");
                    return View(product);
                }

                // Lưu ảnh nếu có
                if (product.ImageUpload != null && product.ImageUpload.Length > 0)
                {
                    string uploadDir = Path.Combine(_webHostEnvironment.WebRootPath, "media/products");
                    string imageName = Guid.NewGuid().ToString() + "_" + Path.GetFileName(product.ImageUpload.FileName);
                    string filePath = Path.Combine(uploadDir, imageName);

                    try
                    {
                        // Tạo thư mục nếu chưa có
                        Directory.CreateDirectory(uploadDir);

                        using (var fs = new FileStream(filePath, FileMode.Create))
                        {
                            await product.ImageUpload.CopyToAsync(fs);
                        }

                        product.Image = imageName; // Gán tên ảnh vào sản phẩm
                    }
                    catch (Exception)
                    {
                        ModelState.AddModelError("", "Không thể tải lên hình ảnh. Vui lòng thử lại sau.");
                        return View(product);
                    }
                }

                _dataContext.Add(product); // Thêm sản phẩm vào DB
                await _dataContext.SaveChangesAsync(); // Lưu vào cơ sở dữ liệu
                TempData["success"] = "Thêm sản phẩm thành công.";
                return RedirectToAction("Index"); // Quay lại danh sách sản phẩm
            }

            // Nếu ModelState không hợp lệ, trả về lại form với lỗi
            TempData["error"] = "Thông tin nhập không hợp lệ. Vui lòng kiểm tra lại các trường và thử lại.";
            return View(product);
        }



        [HttpGet]
        [Route("Edit")]
        public async Task<IActionResult> Edit(int id)
        {
            var product = await _dataContext.Products.FindAsync(id);
            if (product == null)
            {
                return NotFound("Không tìm thấy sản phẩm.");
            }

            ViewBag.Categories = new SelectList(_dataContext.Categories.Where(c => c.Status == 1), "Id", "Name", product.CategoryId);
            ViewBag.Brands = new SelectList(_dataContext.Brands.Where(b => b.Status == 1), "Id", "Name", product.BrandId);
            return View(product);
        }

        [HttpPost]
        [Route("Edit")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(ProductModel product)
        {
            ViewBag.Categories = new SelectList(_dataContext.Categories.Where(c => c.Status == 1), "Id", "Name", product.CategoryId);
            ViewBag.Brands = new SelectList(_dataContext.Brands.Where(b => b.Status == 1), "Id", "Name", product.BrandId);

            var editProduct = await _dataContext.Products.FindAsync(product.Id);
            if (editProduct == null)
            {
                return NotFound("Không tìm thấy sản phẩm.");
            }

            if (ModelState.IsValid)
            {
                editProduct.Slug = product.Name.Replace(" ", "-");
                editProduct.Name = product.Name;
                editProduct.Description = product.Description;
                editProduct.Price = product.Price;
                editProduct.CategoryId = product.CategoryId;
                editProduct.BrandId = product.BrandId;

                if (product.ImageUpload != null && product.ImageUpload.Length > 0)
                {
                    string uploadDir = Path.Combine(_webHostEnvironment.WebRootPath, "media/products");
                    string imageName = Guid.NewGuid().ToString() + "_" + Path.GetFileName(product.ImageUpload.FileName);
                    string filePath = Path.Combine(uploadDir, imageName);

                    Directory.CreateDirectory(uploadDir); // Đảm bảo thư mục tồn tại

                    // Xóa ảnh cũ nếu tồn tại
                    if (!string.IsNullOrEmpty(editProduct.Image))
                    {
                        string oldImagePath = Path.Combine(uploadDir, editProduct.Image);
                        if (System.IO.File.Exists(oldImagePath))
                        {
                            System.IO.File.Delete(oldImagePath);
                        }
                    }

                    using (var fs = new FileStream(filePath, FileMode.Create))
                    {
                        await product.ImageUpload.CopyToAsync(fs);
                    }

                    editProduct.Image = imageName;
                }

                _dataContext.Update(editProduct);
                await _dataContext.SaveChangesAsync();
                TempData["success"] = "Cập nhật sản phẩm thành công.";
                return RedirectToAction("Index");
            }

            TempData["error"] = "Thông tin nhập không hợp lệ.";
            return View(product);
        }

        [HttpGet]
        [Route("Details")]
        public async Task<IActionResult> Details(int Id)
        {
            var product = await _dataContext.Products
                .Include(p => p.Category)
                .Include(p => p.Brand)
                .FirstOrDefaultAsync(p => p.Id == Id);

            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }


		[HttpGet]
		[Route("Delete")]
		public async Task<IActionResult> Delete(int Id)
		{
			// Tìm sản phẩm trong cơ sở dữ liệu
			ProductModel product = await _dataContext.Products.FindAsync(Id);
			if (product == null)
			{
				TempData["error"] = "Sản phẩm không tồn tại.";
				return RedirectToAction("Index");
			}

			// Xóa sản phẩm khỏi cơ sở dữ liệu
			try
			{
				_dataContext.Products.Remove(product);
				await _dataContext.SaveChangesAsync();

				// Nếu xóa sản phẩm thành công, xóa ảnh liên quan
				string upLoadDir = Path.Combine(_webHostEnvironment.WebRootPath, "media/products");
				string oldFileImage = Path.Combine(upLoadDir, product.Image);

				try
				{
					// Kiểm tra nếu ảnh tồn tại và xóa ảnh sản phẩm
					if (System.IO.File.Exists(oldFileImage))
					{
						System.IO.File.Delete(oldFileImage);
					}
					else
					{
						// Thông báo nếu ảnh không tồn tại
						TempData["error"] = "Ảnh sản phẩm không tồn tại để xóa.";
					}
				}
				catch (Exception ex)
				{
					// Thông báo nếu có lỗi khi xóa ảnh và hiển thị chi tiết lỗi
					TempData["error"] = "Lỗi khi xóa ảnh sản phẩm: " + ex.Message;
				}

				// Thông báo thành công và chuyển hướng về trang Index
				TempData["success"] = "Sản phẩm đã xóa thành công.";
			}
			catch (Exception ex)
			{
				// Nếu có lỗi khi xóa sản phẩm khỏi cơ sở dữ liệu, hiển thị lỗi và không xóa ảnh
				TempData["error"] = "Lỗi khi xóa sản phẩm khỏi cơ sở dữ liệu: " + ex.Message;
			}

			// Trở về trang Index
			return RedirectToAction("Index");
		}


		// thêm số lượng sp
		[Route("AddQuantity")]
        [HttpGet]

        public async Task<IActionResult> AddQuantity(int Id)
        {
            var productbyquantity = await _dataContext.ProductQuantities.Where(pq => pq.ProductId == Id).ToListAsync();
            ViewBag.ProductByQuantity = productbyquantity;
            ViewBag.Id = Id;
            return View();
        }

        [Route("StoreProductQuantity")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult StoreProductQuantity(ProductQuantityModel productQuantityModel)
        {
            var product = _dataContext.Products.Find(productQuantityModel.ProductId);

            if (product == null) { return NotFound();}
            
            product.Quantity += productQuantityModel.Quantity;

            productQuantityModel.Quantity = productQuantityModel.Quantity;
            productQuantityModel.ProductId = productQuantityModel.ProductId;
            productQuantityModel.DateCreated = DateTime.Now;

            _dataContext.Add(productQuantityModel);
            _dataContext.SaveChangesAsync();
            TempData["success"] = "Thêm số lượng sản phẩm thành công";
            return RedirectToAction("AddQuantity", "Product", new {Id = productQuantityModel.ProductId });
        }
    }
}
