﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Shopping_Tutorial.Models;
using Shopping_Tutorial.Repository;
using PagedList;
namespace Shopping_Tutorial.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Route("Admin/Category")]
    [Authorize(Roles = "Admin")]
    public class CategoryController : Controller
	{
        private readonly DataContext _dataContext;
        public CategoryController(DataContext context)
        {
            _dataContext = context;

        }
        [HttpGet]
        [Route("Index")]
        public async Task<IActionResult> Index(string searchTerm, int? page, int? pageSize)
        {
            ViewData["CurrentFilter"] = searchTerm;

            // Truy vấn cơ sở dữ liệu
            var categories = _dataContext.Categories.AsQueryable();

            // Áp dụng tìm kiếm nếu có từ khóa
            if (!string.IsNullOrEmpty(searchTerm))
            {
                categories = categories.Where(c => c.Name.Contains(searchTerm) ||
                                                   c.Description.Contains(searchTerm) ||
                                                   c.Slug.Contains(searchTerm));
            }

            // Kiểm tra và gán giá trị mặc định cho trang và số lượng trang
            if (page == null)
            {
                page = 1;
            }
            if (pageSize == null)
            {
                pageSize = 5;
            }

            // Tính toán tổng số mục
            var totalItems = await categories.CountAsync();

            // Tính tổng số trang
            var pageCount = (int)Math.Ceiling(totalItems / (double)pageSize);

            // Lưu vào ViewData để sử dụng trong View
            ViewData["PageCount"] = pageCount;
            ViewData["CurrentPage"] = page;

            // Áp dụng phân trang
            var pagedCategories = categories.OrderByDescending(c => c.Id)
                                             .Skip((page.Value - 1) * pageSize.Value)  // Bỏ qua số lượng phần tử đã hiển thị từ các trang trước
                                             .Take(pageSize.Value); // Lấy số lượng phần tử theo pageSize

            // Chuyển kết quả sang danh sách
            var categoryList = await pagedCategories.ToListAsync();

            // Trả về View với danh sách đã phân trang
            return View(categoryList);
        }

        [HttpGet]
        [Route("Create")]
        public IActionResult Create()
        {

            return View();
        }
        
        [HttpPost]
        [Route("Create")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(CategoryModel category)
        {

            if (ModelState.IsValid)
            {
                //Thêm data
                category.Slug = category.Name.Replace(" ", "-");
                var slug = await _dataContext.Categories.FirstOrDefaultAsync(p => p.Slug == category.Slug);
                if (slug != null)
                {
                    ModelState.AddModelError("", "Danh mục đã có");
                    return View(category);
                }

                _dataContext.Add(category);
                await _dataContext.SaveChangesAsync();
                TempData["success"] = "Thêm danh mục thành công";
                return RedirectToAction("Index");
            }
            else
            {
                TempData["error"] = "Model bị lỗi";
                List<string> errors = new List<string>();
                foreach (var value in ModelState.Values)
                {
                    foreach (var error in value.Errors)
                    {
                        errors.Add(error.ErrorMessage);
                    }
                }
                string errorMessage = string.Join("\n", errors);
                return BadRequest(errorMessage);
            }
            return View(category);
        }

        [HttpGet]
        [Route("Edit")]
        public async Task<IActionResult> Edit(int Id)
        {
            var category = await _dataContext.Categories.FindAsync(Id);
            if (category == null)
            {
                TempData["error"] = "Danh mục không tồn tại";
                return RedirectToAction("Index");
            }

            return View(category);
        }

        [HttpPost]
        [Route("Edit")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(CategoryModel category)
        {
            if (ModelState.IsValid)
            {
                category.Slug = category.Name.Replace(" ", "-");
                var slugExists = await _dataContext.Categories
                    .AnyAsync(p => p.Slug == category.Slug && p.Id != category.Id);

                if (slugExists)
                {
                    ModelState.AddModelError("", "Danh mục đã tồn tại");
                    return View(category);
                }

                _dataContext.Update(category);
                await _dataContext.SaveChangesAsync();
                TempData["success"] = "Cập nhật danh mục thành công";
                return RedirectToAction("Index");
            }

            TempData["error"] = "Vui lòng kiểm tra lại thông tin";
            return View(category);
        }

		[HttpGet]
		[Route("Delete")]
		public async Task<IActionResult> Delete(int Id)
		{
			// Kiểm tra xem có sản phẩm nào thuộc danh mục này không
			var products = await _dataContext.Products
				.Where(p => p.CategoryId == Id)
				.ToListAsync();

			if (products.Any())
			{
				TempData["error"] = "Không thể xóa danh mục vì có sản phẩm thuộc danh mục này.";
				return RedirectToAction("Index");
			}

			// Xóa danh mục
			CategoryModel category = await _dataContext.Categories.FindAsync(Id);
			if (category != null)
			{
				_dataContext.Categories.Remove(category);
				await _dataContext.SaveChangesAsync();
				TempData["success"] = "Danh mục đã xóa";
			}
			else
			{
				TempData["error"] = "Danh mục không tồn tại";
			}
			return RedirectToAction("Index");
		}



		// Thêm hành động Detail trong CategoryController
		[HttpGet]
        [Route("Detail/{Id}")]
        public async Task<IActionResult> Detail(int Id)
        {
            var category = await _dataContext.Categories.FindAsync(Id);

            if (category == null)
            {
                TempData["error"] = "Danh mục không tồn tại";
                return RedirectToAction("Index");
            }

            return View(category); // Trả về View chi tiết của danh mục
        }



    }
}
