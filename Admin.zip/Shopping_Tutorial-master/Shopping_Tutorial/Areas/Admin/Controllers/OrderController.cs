﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Shopping_Tutorial.Models;
using Shopping_Tutorial.Repository;

namespace Shopping_Tutorial.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Route("Admin/Order")]
    [Authorize(Roles = "Admin")]
    public class OrderController : Controller
    {

        private readonly DataContext _dataContext;
        public OrderController(DataContext context)
        {
            _dataContext = context;

        }
        [HttpGet]
        [Route("Index")]
        public async Task<IActionResult> Index(string searchTerm, int? page, int? pageSize)
        {
            // Nếu có tham số tìm kiếm, lọc đơn hàng theo tên người đặt hoặc mã đơn hàng
            var ordersQuery = _dataContext.OrderModels.AsQueryable();

            if (!string.IsNullOrEmpty(searchTerm))
            {
                ordersQuery = ordersQuery.Where(o => o.OrderCode.Contains(searchTerm) || o.UserName.Contains(searchTerm));
                ViewData["CurrentFilter"] = searchTerm; // Giữ lại giá trị tìm kiếm trong form
            }

            // Kiểm tra và gán giá trị mặc định cho trang và số lượng trang
            if (page == null)
            {
                page = 1;
            }
            if (pageSize == null)
            {
                pageSize = 5;
            }

            // Tính toán tổng số đơn hàng
            var totalItems = await ordersQuery.CountAsync();

            // Tính tổng số trang
            var pageCount = (int)Math.Ceiling(totalItems / (double)pageSize);

            // Lưu vào ViewData để sử dụng trong View
            ViewData["PageCount"] = pageCount;
            ViewData["CurrentPage"] = page;

            // Áp dụng phân trang
            var pagedOrders = ordersQuery.OrderByDescending(o => o.Id)
                                         .Skip((page.Value - 1) * pageSize.Value)  // Bỏ qua số lượng phần tử đã hiển thị từ các trang trước
                                         .Take(pageSize.Value); // Lấy số lượng phần tử theo pageSize

            // Chuyển kết quả sang danh sách
            var orderList = await pagedOrders.ToListAsync();

            // Trả về View với danh sách đã phân trang
            return View(orderList);
        }



        [HttpGet]
        [Route("ViewOrder")]
        public async Task<IActionResult> ViewOrder(string orderCode)
        {
            var DetailsOrder = await _dataContext.OrderDetails
                                                 .Include(od => od.product)
                                                 .Where(od => od.OrderCode == orderCode)
                                                 .ToListAsync();
            return View(DetailsOrder); // Truyền danh sách OrderDetails vào View
        }

        [HttpPost]
        [Route("UpdateOrder")]
        public async Task<IActionResult> UpdateOrder(string orderCode, int status)
        {
            if (string.IsNullOrEmpty(orderCode))
            {
                return BadRequest(new { success = false, message = "Mã đơn hàng không hợp lệ." });
            }

            var order = await _dataContext.OrderModels.FirstOrDefaultAsync(o => o.OrderCode == orderCode);
            if (order == null)
            {
                return NotFound(new { success = false, message = "Không tìm thấy đơn hàng." });
            }

            order.Status = status;

            try
            {
                await _dataContext.SaveChangesAsync();
                return Ok(new { success = true, message = "Cập nhật trạng thái đơn hàng thành công." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = "Đã xảy ra lỗi khi cập nhật trạng thái đơn hàng." });
            }
        }
		[HttpPost]
		[Route("DeleteOrder")]
		public async Task<IActionResult> DeleteOrder(int id)
		{
			// Tìm đơn hàng theo Id
			var order = await _dataContext.OrderModels.FindAsync(id);
			if (order == null)
			{
				// Nếu không tìm thấy đơn hàng, trả về 404
				return NotFound();
			}

			// Xóa các chi tiết đơn hàng liên quan trong bảng OrderDetails
			var orderDetails = _dataContext.OrderDetails.Where(od => od.OrderCode == order.OrderCode);
			_dataContext.OrderDetails.RemoveRange(orderDetails);

			// Xóa đơn hàng chính
			_dataContext.OrderModels.Remove(order);

			try
			{
				// Lưu các thay đổi vào cơ sở dữ liệu
				await _dataContext.SaveChangesAsync();

				TempData["success"] = "Đơn hàng và chi tiết đơn hàng đã được xóa thành công!";
				return RedirectToAction("Index");
			}
			catch (Exception ex)
			{
				// Xử lý lỗi nếu có
				TempData["error"] = "Lỗi khi xóa đơn hàng: " + ex.Message;
				return RedirectToAction("Index");
			}
		}

	}
}
