﻿using CK_ASP_NET_CORE.Repository.Validation;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Shopping_Tutorial.Models
{
	public class ProductModel
	{
		[Key]
		public int Id { get; set; }

		// Yêu cầu tên sản phẩm không được trống và có độ dài tối thiểu
		[Required(ErrorMessage = "Yêu cầu nhập Tên sản phẩm")]
		[StringLength(100, ErrorMessage = "Tên sản phẩm không được dài quá 100 ký tự")]
		public string Name { get; set; }

		public string Slug { get; set; }

		// Mô tả sản phẩm yêu cầu nhập và có độ dài tối thiểu
		[Required(ErrorMessage = "Yêu cầu nhập Mô tả sản phẩm")]
		[MinLength(4, ErrorMessage = "Mô tả sản phẩm phải có ít nhất 4 ký tự")]
		[StringLength(1000, ErrorMessage = "Mô tả sản phẩm không được dài quá 1000 ký tự")]
		public string Description { get; set; }

		// Giá sản phẩm phải có giá trị lớn hơn 0
		[Required(ErrorMessage = "Yêu cầu nhập Giá sản phẩm")]
		[Range(0.01, double.MaxValue, ErrorMessage = "Giá sản phẩm phải lớn hơn 0")]
		[Column(TypeName = "decimal(8, 2)")]
		public decimal Price { get; set; }

		// Số lượng và số sản phẩm đã bán phải có giá trị không âm
		[Required(ErrorMessage = "Yêu cầu nhập Số lượng sản phẩm")]
		[Range(0, int.MaxValue, ErrorMessage = "Số lượng phải là số nguyên không âm")]
		public int Quantity { get; set; }

		[Required(ErrorMessage = "Yêu cầu nhập Số lượng đã bán")]
		[Range(0, int.MaxValue, ErrorMessage = "Số lượng đã bán phải là số nguyên không âm")]
		public int Sold { get; set; }

		// Thương hiệu và danh mục phải có giá trị lớn hơn 0
		[Required(ErrorMessage = "Chọn một thương hiệu")]
		[Range(1, int.MaxValue, ErrorMessage = "Chọn một thương hiệu hợp lệ")]
		public int BrandId { get; set; }

		[Required(ErrorMessage = "Chọn một danh mục")]
		[Range(1, int.MaxValue, ErrorMessage = "Chọn một danh mục hợp lệ")]
		public int CategoryId { get; set; }

		// Các đối tượng liên kết với thương hiệu và danh mục
		public CategoryModel Category { get; set; }
		public BrandModel Brand { get; set; }

		// Ảnh sản phẩm
		[StringLength(255, ErrorMessage = "Đường dẫn ảnh không được dài quá 255 ký tự")]
		public string Image { get; set; }

        // Ảnh tải lên có kiểm tra riêng
        [NotMapped]
        [KiemTra]
        public IFormFile? ImageUpload { get; set; }

    }

}
